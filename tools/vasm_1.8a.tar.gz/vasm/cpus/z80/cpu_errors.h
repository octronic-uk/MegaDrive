    "index offset out of bounds (%d)",ERROR,
    "Opcode not supported by %s (%s)",ERROR,
    "Index registers not available on %s",ERROR,
    "out of range for 8 bit expression (%d)",ERROR,
    "invalid bit number (%d) should be in range 0..7",ERROR,
    "rst value out of range (%d/0x%02x)",ERROR,   /* 5 */
    "%s value out of range (%d)",ERROR,
    "index offset should be a constant",ERROR,
    "invalid branch type for %s",ERROR,
    "Rabbit target doesn't support rst %d",ERROR,
    "Rabbit target doesn't support 8 bit index registers",ERROR, /* 10 */
    "z180 target doesn't support 8 bit index registers",ERROR,
    "altd specifier cannot be used with index registers",WARNING,
    "Opcode not supported by %s (%s) but it can be emulated (-rcmemu)",ERROR,
    "%s specifier is only valid for Rabbit processors",ERROR,
    "Only one of ioi and ioe can be specified at a time",ERROR, /* 15 */
    "%s specifier is not valid for the opcode %s",ERROR,
    "%s specifier redundant for the opcode %s",WARNING,
    "%s specifier has no effect on the opcode %s",WARNING,
    "Operand value must evaluate to a constant for opcode %s",ERROR,
    "Unhandled operand type wanted 0x%x got 0x%x",ERROR, /* 20 */
    "Missed matched index registers on %s",ERROR,
    "Only out (c),0 is supported for the opcode %s",ERROR,
    "Operations between different index registers are forbidden",ERROR,
    "Operations between ix/iy/hl are forbidden", ERROR, 
    "Double indirection forbidden", ERROR, /* 25 */
